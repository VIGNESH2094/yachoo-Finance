package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.YahooFinanceHomePage;
import pages.TeslaStockPage;
import java.time.Duration;

public class YahooFinanceTest {
    private WebDriver driver;
    private YahooFinanceHomePage homePage;
    private TeslaStockPage stockPage;

    @BeforeClass
    public void setup() {
      
        driver = new ChromeDriver();
     //   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.manage().window().maximize();
        homePage = new YahooFinanceHomePage(driver);
        stockPage = new TeslaStockPage(driver);
    }

    @Test
    public void testYahooFinanceTeslaStock() {
        driver.get("https://finance.yahoo.com/");     

        // Step 1: Search for Tesla (TSLA)
        homePage.searchStock("TSLA");

        // Step 2: Verify Autosuggest
        Assert.assertTrue(homePage.verifyAutoSuggest("Tesla, Inc."), "Autosuggest entry is incorrect");

        // Step 3: Click on first suggestion
        homePage.clickFirstSuggestion();

        // Step 4: Verify Stock Price is greater than $200
        double stockPrice = stockPage.getStockPrice();
        Assert.assertTrue(stockPrice > 200, "Stock price is less than $200");

        // Step 5: Capture additional data and log it
        System.out.println("Previous Close: " + stockPage.getPreviousClose());
        System.out.println("Volume: " + stockPage.getVolume());
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            //driver.quit();
        }
    }
}
