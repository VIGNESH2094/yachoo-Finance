package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TeslaStockPage {
    private WebDriver driver;
    private By stockPrice = By.xpath("//span[@data-testid = 'qsp-price']");
  //  private By stockPrice = By.xpath("//fin-streamer[@data-field='regularMarketPrice']");
    private By previousClose = By.xpath("//div[@data-testid = 'quote-statistics']/ul/li/span[@title = 'Previous Close']/following-sibling::span/fin-streamer");
    private By volume = By.xpath("//ul/li/span[@title = 'Volume']/following-sibling::span/fin-streamer");

    public TeslaStockPage(WebDriver driver) {
        this.driver = driver;
    }

    public double getStockPrice() {
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	WebElement price = wait.until(ExpectedConditions.presenceOfElementLocated(stockPrice));
    	System.out.println("Stock price :"+price.getText());
        return Double.parseDouble(price.getText().replace(",", ""));
    }

    public String getPreviousClose() {
        return driver.findElement(previousClose).getText();
    }

    public String getVolume() {
        return driver.findElement(volume).getText();
    }
}
