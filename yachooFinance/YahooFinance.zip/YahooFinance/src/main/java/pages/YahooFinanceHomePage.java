package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class YahooFinanceHomePage {
    private WebDriver driver;
    private By searchBox = By.id("ybar-sbq");
    private By autoSuggestFirstEntry = By.xpath("//ul[@role = 'listbox']/li[1]//div[contains(@class, 'CompanyName')]");

    public YahooFinanceHomePage(WebDriver driver) {
        this.driver = driver;
    }

    public void searchStock(String stockSymbol) {
        WebElement search = driver.findElement(searchBox);
        search.clear();
        search. sendKeys(stockSymbol);
    }

    public boolean verifyAutoSuggest(String expectedText) {
        //WebElement firstEntry = driver.findElement(autoSuggestFirstEntry);
    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    	WebElement firstEntry = wait.until(ExpectedConditions.visibilityOfElementLocated(autoSuggestFirstEntry));
        System.out.println(firstEntry.getText());
        return firstEntry.getText().contains(expectedText);
    }

    public void clickFirstSuggestion() {
        driver.findElement(autoSuggestFirstEntry).click();
    }
}


